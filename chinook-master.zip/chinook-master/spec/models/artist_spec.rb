require 'spec_helper'

describe Artist do
  pending "add some examples to (or delete) #{__FILE__}"
end
